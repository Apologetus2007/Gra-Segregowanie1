using System.Runtime.CompilerServices;
using System.Windows.Forms;
using System.Xml;

namespace ProjektGackaGancarz
{
    public partial class Form1 : Form
    {
        private CancellationTokenSource cts;

        private Random rand = new Random();
        private string rodzajOdpadu = "";
        private int numerOdpadu = 0;

        private int punkty = 0;
        private float poziom = 1;

        private int serca = 3;
        private float[] najlepszywynik = { 0, 0, 0, 0, 0 };
        private string sciezkapliku = @"baza.xml";
        public Form1()
        {
            InitializeComponent();
            ukryj();
            aktualizacjaPunktacji();
        }

        private void losujOdpad()
        {
            labelPoziom.Text = poziom.ToString();
            labelPunkty.Text = punkty.ToString();
            numerOdpadu = rand.Next(1, 7);
            if (numerOdpadu == 7) numerOdpadu = 1;
            switch (rand.Next(0, 5))
            {
                case 0:
                    rodzajOdpadu = "TworzywaSztuczne";
                    break;
                case 1:
                    rodzajOdpadu = "Szklo";
                    break;
                case 2:
                    rodzajOdpadu = "Papier";
                    break;
                case 3:
                    rodzajOdpadu = "Bio";
                    break;
                case 4:
                    rodzajOdpadu = "Zmieszane";
                    break;
                default:
                    rodzajOdpadu = "Zmieszane";
                    break;
            }
            if (serca >= 0) sercape.Image = Image.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "zdjecia", "serca", serca.ToString() + ".png"));
            if (serca > 0) Odpad.Image = Image.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "zdjecia", rodzajOdpadu, numerOdpadu.ToString() + ".png"));
            if (serca == 0 && !start.Visible)
            {
                if (najlepszywynik[(int)(poziom - 1)] < punkty) najlepszywynik[(int)(poziom - 1)] = punkty;
                using (XmlWriter xml = XmlWriter.Create(sciezkapliku))
                {
                    xml.WriteStartDocument();
                    xml.WriteStartElement("XML");
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            xml.WriteStartElement("ZapisWyniku");
                            {
                                xml.WriteElementString($"Poziom", najlepszywynik[i].ToString());

                            }
                            xml.WriteEndElement();


                        }
                    }
                    xml.WriteEndElement();
                    xml.WriteEndDocument();
                }

                Console.WriteLine("Pomyslnie zapisano liste!");
                MessageBox.Show("Przegra�e�! :(\n\nPoziom: " + poziom + "\nPunkty: " + punkty);
                ukryj();
            }
            startCzas();
        }
        private async void startCzas()
        {
            cts?.Cancel();
            cts = new CancellationTokenSource();
            var token = cts.Token;

            float czasSetnejSekundy = 0;
            float czasEkran = 0;
            bool czasWyjscie = true;
            try
            {
                while (czasWyjscie && !token.IsCancellationRequested)
                {
                    await Task.Delay(10, token);
                    czasSetnejSekundy++;
                    try
                    {
                        czaslabel.Invoke((MethodInvoker)delegate
                        {
                            czasEkran = ((55 - poziom*9) / 10 - (czasSetnejSekundy / 100));
                            if (serca > 0) czaslabel.Text = czasEkran.ToString("0.00") + " s";
                        });
                    }
                    catch (Exception)
                    {

                    }

                    if (((55 - poziom*9) / 10 - (czasSetnejSekundy / 100)) <= 0)
                    {
                        czasWyjscie = false;
                        serca--;
                        losujOdpad();
                    }
                }
            }
            catch (TaskCanceledException)
            {
                // Gracjan Gacka i Oskar Gancarz
            }
        }

        private void dodajPunkt()
        {
            if (serca > 0) punkty++;
        }

        private void odejmijSerce()
        {
            if (serca > 0 && sercape.Visible) serca--;
        }
        private void TworzywaSztuczneKosz_Click(object sender, EventArgs e)
        {
            if (rodzajOdpadu == "TworzywaSztuczne")
            {
                dodajPunkt();
            }
            else
            {
                odejmijSerce();
            }
            losujOdpad();
        }

        private void SzkloKosz_Click(object sender, EventArgs e)
        {
            if (rodzajOdpadu == "Szklo")
            {
                dodajPunkt();
            }
            else
            {
                odejmijSerce();
            }
            losujOdpad();
        }

        private void PapierKosz_Click(object sender, EventArgs e)
        {
            if (rodzajOdpadu == "Papier")
            {
                dodajPunkt();
            }
            else
            {
                odejmijSerce();
            }
            losujOdpad();
        }

        private void BioKosz_Click(object sender, EventArgs e)
        {
            if (rodzajOdpadu == "Bio")
            {
                dodajPunkt();
            }
            else
            {
                odejmijSerce();
            }
            losujOdpad();
        }

        private void ZmieszaneKosz_Click(object sender, EventArgs e)
        {
            if (rodzajOdpadu == "Zmieszane")
            {
                dodajPunkt();
            }
            else
            {
                odejmijSerce();
            }
            losujOdpad();
        }

        private void start_Click(object sender, EventArgs e)
        {
            losujOdpad();
            pokaz(); 
            if (serca >= 0) sercape.Image = Image.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "zdjecia", "serca", serca.ToString() + ".png"));
            if (serca > 0) Odpad.Image = Image.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "zdjecia", rodzajOdpadu, numerOdpadu.ToString() + ".png"));
        }

        private void ukryj()
        {
            aktualizacjaPunktacji();
            sercape.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            labelPunkty.Visible = false;
            labelPoziom.Visible = false;
            TworzywaSztuczneKosz.Visible = false;
            PapierKosz.Visible = false;
            SzkloKosz.Visible = false;
            BioKosz.Visible = false;
            ZmieszaneKosz.Visible = false;
            Odpad.Visible = false;
            Stop.Visible = false;
            czaslabel.Visible = false;

            start.Visible = true;
            tytul.Visible = true;
            trackBar1.Visible = true;
            numerPoziomu.Visible = true;
            najlepszywyniklabel.Visible = true;

            serca = 3;
            punkty = 0;
        }
        private void pokaz()
        {
            aktualizacjaPunktacji();
            sercape.Visible = true;
            label1.Visible = true;
            label2.Visible = true;
            labelPunkty.Visible = true;
            labelPoziom.Visible = true;
            TworzywaSztuczneKosz.Visible = true;
            PapierKosz.Visible = true;
            SzkloKosz.Visible = true;
            BioKosz.Visible = true;
            ZmieszaneKosz.Visible = true;
            Odpad.Visible = true;
            Stop.Visible = true;
            czaslabel.Visible = true;

            start.Visible = false;
            tytul.Visible = false;
            trackBar1.Visible = false;
            numerPoziomu.Visible = false;
            najlepszywyniklabel.Visible = false;

            serca = 3;
            punkty = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ukryj();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            poziom = trackBar1.Value;
            numerPoziomu.Text = "Poziom " + poziom.ToString();
            aktualizacjaPunktacji();
        }

        private void aktualizacjaPunktacji()
        {
            using (XmlReader xml = XmlReader.Create(sciezkapliku))
            {
                int i = 0;
                string zpd = "";

                while (xml.Read())
                {
                    if (xml.IsStartElement() && xml.Name == "Poziom")
                    {
                        najlepszywynik[i] = int.Parse(xml.ReadString());
                        i++;
                    }
                }
            }
            najlepszywyniklabel.Text = "Najlepszy wynik: " + najlepszywynik[(int)(poziom - 1)].ToString();
        }
    }
}