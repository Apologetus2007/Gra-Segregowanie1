﻿namespace ProjektGackaGancarz
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            TworzywaSztuczneKosz = new Button();
            SzkloKosz = new Button();
            PapierKosz = new Button();
            BioKosz = new Button();
            ZmieszaneKosz = new Button();
            Odpad = new PictureBox();
            sercape = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            labelPunkty = new Label();
            labelPoziom = new Label();
            start = new Button();
            Stop = new Button();
            czaslabel = new Label();
            tytul = new Label();
            trackBar1 = new TrackBar();
            numerPoziomu = new Label();
            najlepszywyniklabel = new Label();
            ((System.ComponentModel.ISupportInitialize)Odpad).BeginInit();
            ((System.ComponentModel.ISupportInitialize)sercape).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            SuspendLayout();
            // 
            // TworzywaSztuczneKosz
            // 
            TworzywaSztuczneKosz.BackColor = Color.Yellow;
            TworzywaSztuczneKosz.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            TworzywaSztuczneKosz.Location = new Point(7, 214);
            TworzywaSztuczneKosz.Name = "TworzywaSztuczneKosz";
            TworzywaSztuczneKosz.Size = new Size(150, 150);
            TworzywaSztuczneKosz.TabIndex = 0;
            TworzywaSztuczneKosz.Text = "Tworzywa Sztuczne";
            TworzywaSztuczneKosz.UseVisualStyleBackColor = false;
            TworzywaSztuczneKosz.Click += TworzywaSztuczneKosz_Click;
            // 
            // SzkloKosz
            // 
            SzkloKosz.BackColor = Color.Green;
            SzkloKosz.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            SzkloKosz.Location = new Point(163, 214);
            SzkloKosz.Name = "SzkloKosz";
            SzkloKosz.Size = new Size(150, 150);
            SzkloKosz.TabIndex = 1;
            SzkloKosz.Text = "Szkło";
            SzkloKosz.UseVisualStyleBackColor = false;
            SzkloKosz.Click += SzkloKosz_Click;
            // 
            // PapierKosz
            // 
            PapierKosz.BackColor = Color.Blue;
            PapierKosz.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            PapierKosz.Location = new Point(319, 214);
            PapierKosz.Name = "PapierKosz";
            PapierKosz.Size = new Size(150, 150);
            PapierKosz.TabIndex = 2;
            PapierKosz.Text = "Papier";
            PapierKosz.UseVisualStyleBackColor = false;
            PapierKosz.Click += PapierKosz_Click;
            // 
            // BioKosz
            // 
            BioKosz.BackColor = Color.FromArgb(128, 64, 64);
            BioKosz.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            BioKosz.Location = new Point(475, 214);
            BioKosz.Name = "BioKosz";
            BioKosz.Size = new Size(150, 150);
            BioKosz.TabIndex = 3;
            BioKosz.Text = "Biodegradowalne";
            BioKosz.UseVisualStyleBackColor = false;
            BioKosz.Click += BioKosz_Click;
            // 
            // ZmieszaneKosz
            // 
            ZmieszaneKosz.BackColor = Color.Gray;
            ZmieszaneKosz.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            ZmieszaneKosz.Location = new Point(631, 214);
            ZmieszaneKosz.Name = "ZmieszaneKosz";
            ZmieszaneKosz.Size = new Size(150, 150);
            ZmieszaneKosz.TabIndex = 4;
            ZmieszaneKosz.Text = "Zmieszane";
            ZmieszaneKosz.UseVisualStyleBackColor = false;
            ZmieszaneKosz.Click += ZmieszaneKosz_Click;
            // 
            // Odpad
            // 
            Odpad.Location = new Point(319, 38);
            Odpad.Name = "Odpad";
            Odpad.Size = new Size(150, 150);
            Odpad.TabIndex = 5;
            Odpad.TabStop = false;
            // 
            // sercape
            // 
            sercape.Image = (Image)resources.GetObject("sercape.Image");
            sercape.Location = new Point(12, 12);
            sercape.Name = "sercape";
            sercape.Size = new Size(120, 60);
            sercape.TabIndex = 6;
            sercape.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(25, 101);
            label1.Name = "label1";
            label1.Size = new Size(66, 20);
            label1.TabIndex = 7;
            label1.Text = "Punkty: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(25, 75);
            label2.Name = "label2";
            label2.Size = new Size(65, 20);
            label2.TabIndex = 8;
            label2.Text = "Poziom:";
            // 
            // labelPunkty
            // 
            labelPunkty.AutoSize = true;
            labelPunkty.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            labelPunkty.Location = new Point(96, 101);
            labelPunkty.Name = "labelPunkty";
            labelPunkty.Size = new Size(18, 20);
            labelPunkty.TabIndex = 9;
            labelPunkty.Text = "0";
            // 
            // labelPoziom
            // 
            labelPoziom.AutoSize = true;
            labelPoziom.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            labelPoziom.Location = new Point(96, 75);
            labelPoziom.Name = "labelPoziom";
            labelPoziom.Size = new Size(18, 20);
            labelPoziom.TabIndex = 10;
            labelPoziom.Text = "0";
            // 
            // start
            // 
            start.Font = new Font("Comic Sans MS", 36F, FontStyle.Bold, GraphicsUnit.Point);
            start.Location = new Point(238, 137);
            start.Name = "start";
            start.Size = new Size(305, 98);
            start.TabIndex = 11;
            start.Text = "Start";
            start.UseVisualStyleBackColor = true;
            start.Click += start_Click;
            // 
            // Stop
            // 
            Stop.Font = new Font("Comic Sans MS", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            Stop.Location = new Point(632, 12);
            Stop.Name = "Stop";
            Stop.Size = new Size(149, 43);
            Stop.TabIndex = 12;
            Stop.Text = "Wyjdź";
            Stop.UseVisualStyleBackColor = true;
            Stop.Click += button1_Click;
            // 
            // czaslabel
            // 
            czaslabel.AutoSize = true;
            czaslabel.Location = new Point(373, 12);
            czaslabel.Name = "czaslabel";
            czaslabel.Size = new Size(0, 15);
            czaslabel.TabIndex = 14;
            czaslabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tytul
            // 
            tytul.AutoSize = true;
            tytul.Font = new Font("Comic Sans MS", 48F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            tytul.ForeColor = Color.DarkGoldenrod;
            tytul.Location = new Point(96, 27);
            tytul.Name = "tytul";
            tytul.Size = new Size(583, 90);
            tytul.TabIndex = 15;
            tytul.Text = "SEGREGOWANIE";
            // 
            // trackBar1
            // 
            trackBar1.LargeChange = 1;
            trackBar1.Location = new Point(238, 278);
            trackBar1.Maximum = 5;
            trackBar1.Minimum = 1;
            trackBar1.Name = "trackBar1";
            trackBar1.Size = new Size(305, 45);
            trackBar1.TabIndex = 1;
            trackBar1.Value = 1;
            trackBar1.Scroll += trackBar1_Scroll;
            // 
            // numerPoziomu
            // 
            numerPoziomu.AutoSize = true;
            numerPoziomu.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            numerPoziomu.Location = new Point(238, 252);
            numerPoziomu.Name = "numerPoziomu";
            numerPoziomu.Size = new Size(77, 23);
            numerPoziomu.TabIndex = 17;
            numerPoziomu.Text = "Poziom 1";
            // 
            // najlepszywyniklabel
            // 
            najlepszywyniklabel.AutoSize = true;
            najlepszywyniklabel.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point);
            najlepszywyniklabel.Location = new Point(373, 252);
            najlepszywyniklabel.Name = "najlepszywyniklabel";
            najlepszywyniklabel.Size = new Size(158, 23);
            najlepszywyniklabel.TabIndex = 18;
            najlepszywyniklabel.Text = "Najlepszy wynik: 0";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(793, 377);
            Controls.Add(najlepszywyniklabel);
            Controls.Add(numerPoziomu);
            Controls.Add(trackBar1);
            Controls.Add(tytul);
            Controls.Add(czaslabel);
            Controls.Add(Stop);
            Controls.Add(start);
            Controls.Add(labelPoziom);
            Controls.Add(labelPunkty);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(sercape);
            Controls.Add(Odpad);
            Controls.Add(ZmieszaneKosz);
            Controls.Add(BioKosz);
            Controls.Add(PapierKosz);
            Controls.Add(SzkloKosz);
            Controls.Add(TworzywaSztuczneKosz);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MaximumSize = new Size(809, 416);
            MinimumSize = new Size(809, 416);
            Name = "Form1";
            Text = "Segregowanie";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)Odpad).EndInit();
            ((System.ComponentModel.ISupportInitialize)sercape).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button TworzywaSztuczneKosz;
        private Button SzkloKosz;
        private Button PapierKosz;
        private Button BioKosz;
        private Button ZmieszaneKosz;
        private PictureBox Odpad;
        private PictureBox sercape;
        private Label label1;
        private Label label2;
        private Label labelPunkty;
        private Label labelPoziom;
        private Button start;
        private Button Stop;
        private ProgressBar czas;
        private Label czaslabel;
        private Label tytul;
        private TrackBar trackBar1;
        private Label numerPoziomu;
        private Label najlepszywyniklabel;
    }
}